class AppImages{
  static String bitcoin = 'assets/images/bitcoin.png';
}