import 'package:flutter/material.dart';

class AppColors{
  static Color backgroundColor = Color(0xff0b9597);
  static Color white = Colors.white;
  static Color black = Colors.black;
  static Color textColor = Color(0xffb1af4d);
}