class CurrencyModel {
  String countryCode;
  double rate;

  CurrencyModel({required this.countryCode, required this.rate});
}
