class QueryParams {
  getMapsQueryParams() {
    var body = {
      "location": "23.03744,72.566",
      "rankby": "distance",
      "sensor": "true",
      "key": "AIzaSyB2Az9gVUzQULUc55xQD9AE7gj9Ni5hvJk",
    };
    return body;
  }
}
