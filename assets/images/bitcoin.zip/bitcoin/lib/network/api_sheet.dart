class ApiSheet {
  static String mapKey = "AIzaSyCBx6fwafrrtcQdZUiq3pzkr2oFYnQwoUI";
  static String mapsBaseUrl =
      "https://maps.googleapis.com/maps/api/place/findplacefromtext/json?";
}
